package com.ark.ark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArkApplicationTests {

	@Test
	void contextLoads() {
	}

}
