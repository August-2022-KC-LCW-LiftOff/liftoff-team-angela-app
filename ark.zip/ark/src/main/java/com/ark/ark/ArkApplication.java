package com.ark.ark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArkApplication.class, args);
	}

}
